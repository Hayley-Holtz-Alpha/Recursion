package CharacterCount;

import java.util.Scanner;

public class CharacterCountDemo {

    public static void main(String[] args) {
        //Creates the input statement
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter String here: ");
        String word = sc.next();

        System.out.println("Enter character: ");
        //This line is responsable for the letter selection is random however
        char c = sc.next().charAt(0);


        int count = count(word, c);
        System.out.println(String.format("%d occurrences of %c in %s", count, c, word));
    }

    //Counter code
    public static int count(String str, char a) {
        //Checks if the String has more than 0 characters
        if (str.length() == 0) {
            return 0;
        }
            int count = 0;
        if (str.charAt(0) == a)
        {
            count++;
        }
        return count + count(str.substring(1), a);
    }
}